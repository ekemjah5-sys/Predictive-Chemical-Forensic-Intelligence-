import pandas as pd
from rdkit import Chem
from rdkit.Chem import Descriptors, Fragments

print("=== STARTING STEP 3: FORENSIC PASSPORT & THERMODYNAMIC ESTIMATION ===")

# Raw structural dictionary from our successful database
molecular_repository = {
    "P2P_Precursor": "CC(=O)CC1=CC=CC=C1",
    "N_Formylmethamphetamine": "CC(CC1=CC=CC=C1)N(C)C=O",
    "Dibenzyl_Ketone_Impurity": "C1=CC=C(C=C1)CC(=O)CC2=CC=CC=C2",
    "Ephedrine_Precursor": "CC(C(C1=CC=CC=C1)O)NC",
    "Cis_Aziridine_Impurity": "CC1N(C)C1C2=CC=CC=C2",
    "Chloroephedrine_Intermediate": "CC(C(C1=CC=CC=C1)Cl)NC",
    "Methamphetamine_Product": "CC(CC1=CC=CC=C1)NC"
}

passport_records = []

for name, smiles in molecular_repository.items():
    mol = Chem.MolFromSmiles(smiles)
    
    # 1. Advanced Structural Informatics Descriptors
    rotatable_bonds = Descriptors.NumRotatableBonds(mol) # Measures molecular flexibility
    aromatic_rings = Descriptors.NumAromaticRings(mol)   # Count of benzene structures
    
    # 2. Extract Functional Groups (Crucial for identifying dirty, unreacted chemicals)
    has_hydroxyl = Fragments.fr_Al_OH(mol)  # Detects unreacted Ephedrine alcohol groups
    has_halogen = smiles.count('Cl') + smiles.count('I') # Detects crude reaction remnants
    
    # 3. Thermodynamic Estimation Proxy 
    # (High rotatable bonds & large weight increase structural entropy; aromatic rings add stability)
    # This formula estimates relative internal energy states for chemometric modeling
    estimated_stability_index = (Descriptors.MolWt(mol) * 0.1) - (rotatable_bonds * 0.5) + (aromatic_rings * 2.3)

    passport_records.append({
        "Molecule": name,
        "Rotatable_Bonds": rotatable_bonds,
        "Aromatic_Rings": aromatic_rings,
        "Hydroxyl_Group": "YES" if has_hydroxyl > 0 else "NO",
        "Halogen_Present": "YES" if has_halogen > 0 else "NO",
        "Stability_Index": round(estimated_stability_index, 2)
    })
    print(f"Generated Forensic Passport Features for: {name}")

# Compile into the Passport Framework Dataframe
passport_df = pd.DataFrame(passport_records)

print("\n=== STEP 3 COMPLETE: FORENSIC CHEMICAL PASSPORT MATRIX ===")
print(passport_df.to_string(index=False))
