import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

print("=== STARTING STEP 5 (OPTIMIZED): FORENSIC ML FEATURE ENGINERING ===")

# 1. Load the dataset
df = pd.read_csv("nigerian_forensic_seizures.csv")

# 2. ADVANCED FORENSIC FEATURE ENGINEERING
# We create synthetic multi-dimensional chemical ratios to clean up the overlapping noise
df["MW_per_TPSA"] = df["Mol_Weight_Observed"] / (df["TPSA_Observed"] + 0.1)
df["LogP_x_Stability"] = df["LogP_Observed"] * df["Stability_Index"]

# 3. Isolate the upgraded feature set (X) and Target Label (y)
X = df[["Mol_Weight_Observed", "LogP_Observed", "TPSA_Observed", "Rotatable_Bonds", "Stability_Index", "MW_per_TPSA", "LogP_x_Stability"]]
y = df["True_Synthetic_Route"]

# 4. Train-Test Split (80% Train, 20% Test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42, stratify=y)

# 5. Initialize Optimization Model with adjusted tree depth to prevent overfitting
forensic_model = RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42)
forensic_model.fit(X_train, y_train)

# 6. Evaluate optimized performance
predictions = forensic_model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print("\n=== STEP 5 OPTIMIZED METRICS: EVALUATION REPORT ===")
print(f"Overall Model Tracing Accuracy: {accuracy * 100:.2f}%")
print("\nDetailed Performance Diagnostics per Route Category:")
print(classification_report(y_test, predictions))

# 7. Extract Upgraded Variable Importances
importances = forensic_model.feature_importances_
feature_names = X.columns

print("=== OPTIMIZED FORENSIC VARIABLE IMPORTANCE RANKING ===")
for name, importance in zip(feature_names, importances):
    print(f" -> Feature [{name:22s}]: Relative Tracing Weight = {importance:.4f}")
