import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

def generate_reproducible_pipeline():
    print("=== INITIALIZING COMPUTATIONAL REPRODUCIBILITY ENGINE ===")
    
    # 1. Establish Random Seed for Scientific Consistency (as noted in methodology)
    np.random.seed(42)
    total_samples = 200
    dataset = []

    print(f"Generating synthetic forensic training matrix ({total_samples} samples)...")
    
    # 2. Replicate the distinct population distributions for both synthetic tracks
    for i in range(total_samples):
        route = np.random.choice(["P2P_Leuckart", "Ephedrine_Iodine"])
        
        if route == "P2P_Leuckart":
            # Profile characterization: Heavier mass, higher lipophilicity, moderate TPSA
            mol_wt   = np.random.normal(177.24, 4.0)     
            log_p    = np.random.normal(2.35, 0.15)       
            tpsa     = np.random.normal(18.69, 1.0)      
            rot_b    = max(1, int(np.random.normal(4, 0.4)))
            stab_idx = np.random.normal(18.79, 0.8)
        else:
            # Profile characterization: Lighter intermediate masses, lower LogP, higher TPSA
            mol_wt   = np.random.normal(156.22, 4.0)     
            log_p    = np.random.normal(1.69, 0.15)       
            tpsa     = np.random.normal(25.76, 1.8)      
            rot_b    = max(1, int(np.random.normal(2, 0.4)))
            stab_idx = np.random.normal(16.85, 0.8)
            
        location = np.random.choice(["Lagos_Seaport", "Seme_Border", "Abidagba_Forest_Lab", "Kano_Highway_Intercept"])
        
        dataset.append({
            "Seizure_ID": f"NGA-2026-{i+1:03d}",
            "Seizure_Location": location,
            "Mol_Weight_Observed": round(mol_wt, 3),
            "LogP_Observed": round(log_p, 3),
            "TPSA_Observed": round(tpsa, 3),
            "Rotatable_Bonds": rot_b,
            "Stability_Index": round(stab_idx, 2),
            "True_Synthetic_Route": route
        })

    # Convert raw dictionary entries into a baseline dataframe matrix
    df = pd.DataFrame(dataset)
    
    # 3. IMPLEMENT EXTRACTED MATHEMATICAL FEATURE RATIOS (Equations 1 & 2)
    print("Executing advanced chemometric feature engineering functions...")
    df["MW_per_TPSA"] = df["Mol_Weight_Observed"] / (df["TPSA_Observed"] + 0.1)
    df["LogP_x_Stability"] = df["LogP_Observed"] * df["Stability_Index"]
    
    # Isolate independent analytical variables (X) and ground truth target vector (y)
    feature_cols = [
        "Mol_Weight_Observed", "LogP_Observed", "TPSA_Observed", 
        "Rotatable_Bonds", "Stability_Index", "MW_per_TPSA", "LogP_x_Stability"
    ]
    X = df[feature_cols]
    y = df["True_Synthetic_Route"]

    # 4. Partition into historical training sets and hidden operational test arrays
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    # 5. Fit the hyperparameter-constrained Random Forest model
    print("Training optimized Random Forest Classifier engine...")
    forensic_model = RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42)
    forensic_model.fit(X_train, y_train)
    
    # 6. Evaluate and report classification metrics against the blind validation set
    predictions = forensic_model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    
    print("\n" + "="*50)
    print("REPRODUCIBILITY EVALUATION VERIFIED REPORT")
    print("="*50)
    print(f"Overall Model Tracing Accuracy: {accuracy * 100:.2f}%")
    print("\nDetailed Diagnostic Breakdown:")
    print(classification_report(y_test, predictions))
    
    # 7. Extract and rank the Gini variables relative tracking weights
    print("="*50)
    print("REPRODUCIBLE VARIABLE IMPORTANCE RANKINGS")
    print("="*50)
    importances = forensic_model.feature_importances_
    for name, importance in sorted(zip(feature_cols, importances), key=lambda x: x[1], reverse=True):
        print(f" -> Feature [{name:20s}]: Calculated Weight = {importance:.4f}")
        
    # Save the reproduced dataset for data availability consistency checks
    os.makedirs("supporting_information", exist_ok=True)
    df.to_csv("supporting_information/nigerian_forensic_seizures.csv", index=False)
    print("\n[SUCCESS] Baseline data matrix cleanly archived in supporting_information/")

if __name__ == "__main__":
    generate_reproducible_pipeline()
