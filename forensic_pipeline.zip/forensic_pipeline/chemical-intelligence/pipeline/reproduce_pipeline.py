import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

def generate_reproducible_pipeline():
    print('=== INITIALIZING COMPUTATIONAL REPRODUCIBILITY ENGINE ===')
    np.random.seed(42)
    total_samples = 200
    dataset = []
    for i in range(total_samples):
        route = np.random.choice(['P2P_Leuckart', 'Ephedrine_Iodine'])
        if route == 'P2P_Leuckart':
            wt, lp, tp, rb, st = np.random.normal(177.24, 4.0), np.random.normal(2.35, 0.15), np.random.normal(18.69, 1.0), max(1, int(np.random.normal(4, 0.4))), np.random.normal(18.79, 0.8)
        else:
            wt, lp, tp, rb, st = np.random.normal(156.22, 4.0), np.random.normal(1.69, 0.15), np.random.normal(25.76, 1.8), max(1, int(np.random.normal(2, 0.4))), np.random.normal(16.85, 0.8)
        dataset.append({'Seizure_ID': f'NGA-2026-{i+1:03d}', 'Seizure_Location': np.random.choice(['Lagos_Seaport', 'Seme_Border', 'Abidagba_Forest_Lab', 'Kano_Highway_Intercept']), 'Mol_Weight_Observed': round(wt, 3), 'LogP_Observed': round(lp, 3), 'TPSA_Observed': round(tp, 3), 'Rotatable_Bonds': rb, 'Stability_Index': round(st, 2), 'True_Synthetic_Route': route})
    df = pd.DataFrame(dataset)
    df['MW_per_TPSA'] = df['Mol_Weight_Observed'] / (df['TPSA_Observed'] + 0.1)
    df['LogP_x_Stability'] = df['LogP_Observed'] * df['Stability_Index']
    feature_cols = ['Mol_Weight_Observed', 'LogP_Observed', 'TPSA_Observed', 'Rotatable_Bonds', 'Stability_Index', 'MW_per_TPSA', 'LogP_x_Stability']
    X, y = df[feature_cols], df['True_Synthetic_Route']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42, stratify=y)
    forensic_model = RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42).fit(X_train, y_train)
    predictions = forensic_model.predict(X_test)
    print('\nOverall Model Tracing Accuracy:', accuracy_score(y_test, predictions) * 100, '%')
    print(classification_report(y_test, predictions))

if __name__ == '__main__':
    generate_reproducible_pipeline()
