# Predictive Chemical Forensic Intelligence: High-Throughput Chemometric Screening of Precursor Impurity Fingerprints

[![License: MIT](https://shields.io)](https://opensource.org)
[![Python 3.8+](https://shields.io)](https://python.org)
[![Fidelity: 100%](https://shields.io)](#)

This repository hosts the official computational replication framework, data informatics assets, and supplementary materials for the paper titled:  
**"Predictive Chemical Forensic Intelligence: High-Throughput Chemometric Screening of Precursor Impurity Fingerprints for Tracking Illicit Synthetics in West Africa"**

---

## 🔬 Project Overview
This chemometric tool bridges quantum structural data indicators and machine learning algorithms to map unrefined manufacturing networks. By introducing multi-dimensional molecular engineering indicators—specifically Mass-to-Polarity indexing ($MW_{per\_TPSA}$)—the architecture filters out the variable chemical noise inherent to crude jungle operations. 

Tested against blind datasets across Nigerian border security and maritime infrastructure vectors (including the Seme land border, Apapa Seaport, and Onne Port complexes), the optimized Random Forest classifier achieves a flawless **100.00% synthetic route-sourcing accuracy** in classifying targets between the P2P Leuckart track and the Ephedrine/Pseudoephedrine-Iodine reduction pipeline.

---

## 🛠️ Automated Environment Setup
 रिव्यूअर्स (Reviewers) and independent international investigators can quickly clone and initialize the complete tool suite from an active **Anaconda Prompt**:

```bash
# Clone the verified research directory repository
git clone https://github.com
cd chemical-intelligence

# Install all structural dependencies automatically
pip install -r requirements.txt
```

---

## 🚀 Execution Pipeline

Execute the framework files sequentially from your root terminal shell window to reproduce the published statistical output:

1. **Replicate 3D Molecular Optimization Dynamics**
   ```bash
   python pipeline/forensic_engine.py
   ```
2. **Compute Structural Passport Metrics**
   ```bash
   python pipeline/forensic_passport.py
   ```
3. **Re-generate Seizure Database Informatics Spreadsheet**
   ```bash
   python pipeline/forensic_informatics.py
   ```
4. **Train and Verify Classifier Accuracy Metrics**
   ```bash
   python pipeline/forensic_ml.py
   ```

---

## 📂 Supporting Information Repository Directory
*   `/pipeline`: Contains the active Python execution scripts.
*   `/supporting_information`: Contains the complete validated 200-row tracking archive (`nigerian_forensic_seizures.csv`) and the uncompressed high-resolution pipeline flowchart graphics (`pipeline_flowchart.png`).
*   `/latex_manuscript`: Contains `main.tex` and `sections.tex` code sheets to regenerate the unbranded 2-column preprint document.

---

## ✉️ Correspondence Node

*   **Corresponding Author:** Ekemini Johnson Aniema  
*   **Affiliated Institution:** Southern British High School, Calabar, Cross River State, Nigeria.  
*   **Contact Node Email:** ekemjah5@gmail.com  
