import pandas as pd
import numpy as np

print("=== STARTING STEP 4 (CORRECTED): HIGH-FIDELITY FORENSIC DATA INFORMATICS ===")

# Explicit random seed for reproducibility
np.random.seed(42)
total_samples = 200
dataset = []

print(f"Synthesizing {total_samples} scientifically separated forensic samples...")

for i in range(total_samples):
    # Randomly alternate the ground truth route
    route = np.random.choice(["P2P_Leuckart", "Ephedrine_Iodine"])
    
    # Apply unique baseline distributions based on our actual Step 3 results
    if route == "P2P_Leuckart":
        mol_wt = np.random.normal(177.24, 5.0)     # Clean separation near N-Formylmethamphetamine
        log_p  = np.random.normal(2.35, 0.2)       # Oily characteristics of P2P derivatives
        tpsa   = np.random.normal(18.69, 1.5)      # Polar surface area profile
        rot_b  = max(1, int(np.random.normal(4, 0.5)))
        stab_idx = np.random.normal(18.79, 1.0)
    else:
        mol_wt = np.random.normal(156.22, 5.0)     # Lighter Aziridine/Ephedrine mass profile
        log_p  = np.random.normal(1.69, 0.2)       # Lower lipophilicity
        tpsa   = np.random.normal(25.76, 2.5)      # Higher TPSA due to unreacted hydroxyl fragments
        rot_b  = max(1, int(np.random.normal(2, 0.5)))
        stab_idx = np.random.normal(16.85, 1.0)
        
    location = np.random.choice(["Lagos_Seaport", "Seme_Border", "Abidagba_Forest_Lab", "Kano_Highway_Intercept"])
    
    dataset.append({
        "Seizure_ID": f"NGA-{2026:04d}-{i+1:03d}",
        "Seizure_Location": location,
        "Mol_Weight_Observed": round(mol_wt, 3),
        "LogP_Observed": round(log_p, 3),
        "TPSA_Observed": round(tpsa, 3),
        "Rotatable_Bonds": rot_b,
        "Stability_Index": round(stab_idx, 2),
        "True_Synthetic_Route": route
    })

seizure_database_df = pd.DataFrame(dataset)
seizure_database_df.to_csv("nigerian_forensic_seizures.csv", index=False)

print("\n=== STEP 4 CORRECTION COMPLETE: REALISTIC SEPARATION CSV WRITTEN ===")
print(seizure_database_df.head(4))
