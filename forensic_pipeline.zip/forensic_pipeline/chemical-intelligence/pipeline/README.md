# Predictive Chemical Forensic Intelligence Framework
Computational pipeline for high-throughput screening of precursor impurity profiles in West Africa.
## Execution Order
1. Run structure optimization: `python pipeline/forensic_engine.py`
2. Extract forensic descriptors: `python pipeline/forensic_passport.py`
3. Generate sample matrix: `python pipeline/forensic_informatics.py`
4. Train/test classifier: `python pipeline/forensic_ml.py`
5. Generate publication flowchart: `python pipeline/forensic_flowchart.py`
