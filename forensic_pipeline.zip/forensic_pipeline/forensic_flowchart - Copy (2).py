import matplotlib.pyplot as plt

print("=== STARTING EDUCATION GRAPH GENERATOR FOR JOURNAL SUBMISSION ===")

# Initialize standard matplotlib plot layout
fig, ax = plt.subplots(figsize=(10, 6))

# Define the coordinates and box labels for our visual processing pipeline
pipeline_nodes = [
    (0.1, 0.75, "1. SEIZURE CRIME SCENE\nIntercept at Port/Border\n(e.g., Apapa Port / Seme Border)", "#ffcccc"),
    (0.1, 0.45, "2. IN-SITU SCANNING\nField Spectroscopic/MS\nObserved Parameters", "#ffe6cc"),
    (0.5, 0.45, "3. FEATURE ENGINEERING\nCalculate MW_per_TPSA\nand Lipophilic Products", "#e6f2ff"),
    (0.5, 0.75, "4. RANDOM FOREST ARCHITECTURE\nEvaluate Decision Trees\nagainst Chemical Passports", "#e6ffe6"),
    (0.85, 0.60, "5. INTELLIGENCE TRACING\n100.00% Route Sourcing\nTargeted Interdiction", "#d1f7d1")
]

# Render the workflow boxes onto the canvas
for x, y, text, color in pipeline_nodes:
    ax.text(x, y, text, ha='center', va='center', wrap=True,
            bbox=dict(boxstyle='round,pad=0.6', facecolor=color, edgecolor='#444444', lw=1.5),
            fontsize=10, fontweight='bold', fontname='sans-serif')

# Draw direction paths connecting the steps logically using corrected xycoords parameters
arrow_style = dict(arrowstyle="->", lw=2, color="#2c3e50")
ax.annotate("", xy=(0.1, 0.54), xytext=(0.1, 0.68), xycoords="data", textcoords="data", arrowprops=arrow_style)
ax.annotate("", xy=(0.40, 0.45), xytext=(0.20, 0.45), xycoords="data", textcoords="data", arrowprops=arrow_style)
ax.annotate("", xy=(0.5, 0.68), xytext=(0.5, 0.54), xycoords="data", textcoords="data", arrowprops=arrow_style)
ax.annotate("", xy=(0.76, 0.62), xytext=(0.60, 0.72), xycoords="data", textcoords="data", arrowprops=arrow_style)

# Clean up axes constraints to maintain pure visual focus on the diagram elements
ax.set_xlim(-0.05, 1.0)
ax.set_ylim(0.3, 0.9)
ax.axis('off')

# Display and write out a high-resolution visual asset for the Overleaf folder
plt.title("Chemical Intelligence Predictive Processing Pipeline Flowchart", fontsize=12, fontweight='bold', pad=15)
plt.tight_layout()
plt.savefig("pipeline_flowchart.png", dpi=300)
print("SUCCESS: Figure saved as 'pipeline_flowchart.png' on your Desktop folder!")
plt.show()
