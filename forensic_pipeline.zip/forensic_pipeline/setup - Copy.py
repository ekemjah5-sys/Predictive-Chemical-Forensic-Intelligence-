from setuptools import setup, find_packages

setup(
    name="chemical_forensic_intel",
    version="1.0.0",
    author="Ekemini Johnson Aniema",
    author_email="ekemjah5@gmail.com",
    description="High-Throughput Chemometric Screening of Precursor Impurity Fingerprints",
    url="https://github.com",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "rdkit>=2023.03.1",
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "scikit-learn>=1.2.0",
        "matplotlib>=3.7.0"
    ],
)

